package shapesdemo;
public class Rectangle extends Shape{
    
    private double width , height;

    public Rectangle(double width, double height) {
        this.width = width;
        this.height = height;
    }

    public double getWidth() {
        return width;
    }

    public void setWidth(double width) {
        this.width = width;
    }

    public double getHeight() {
        return height;
    }

    public void setHeight(double height) {
        this.height = height;
    }

    @Override
    public double findArea()
    {
        return this.width * this.height;
    }
    
    
    @Override
    public int findNumberOfCorners()
    {
        return 4;
    }
    @Override
    public boolean equals(Object obj)
    {
        
        if(this==obj) return true;
        
        if(obj==null || this.getClass() !=obj.getClass()) return false;
        
        Rectangle r = (Rectangle) obj;
        
        return this.width == r.width && this.height == r.height;
        
    }
    
    
    @Override
    public String toString() {
        return "Rectangle{" + "width=" + width + ", height=" + height + '}';
    }
    
    public static void main(String[] args) {
        Rectangle r1=new Rectangle(2, 2);
        
        Rectangle r2 =new Rectangle(2, 6);
        
        System.out.println(r1.equals(r2));
    }
    
    
    
}