package shapesdemo;
public abstract class Shape extends Object{
    
    private String name;
    private int numberOfCorners;

    public Shape() {
    }
    
    

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getNumberOfCorners() {
        return numberOfCorners;
    }

    public void setNumberOfCorners(int numberOfCorners) {
        this.numberOfCorners = numberOfCorners;
    }
    
    
    public abstract double findArea();

    @Override
    public String toString() {
        return "Shape{" + "name=" + name + ", numberOfCorners=" + numberOfCorners + '}';
    }
    
    public abstract int findNumberOfCorners();
    
    
    
}