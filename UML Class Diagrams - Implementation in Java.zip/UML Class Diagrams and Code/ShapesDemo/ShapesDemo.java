package shapesdemo;

import java.util.ArrayList;
public class ShapesDemo {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here

        ArrayList<Shape> shapes = new ArrayList<>();
        shapes.add(new Shape());
        shapes.add(new Rectangle(2, 2));
        shapes.add(new Circle(5));
        shapes.add(new Shape());
        Shape shape1 = new Shape();
        Shape shape2 = new Rectangle(3, 3);
        Shape shape3 = new Circle(3);
        shapes.add(shape1);
        shapes.add(shape2);
        shapes.add(shape3);
        
//        for(Shape s:shapes)
//        {
//            System.out.println(s);
//        }

        for (Shape s : shapes) {
            if (s instanceof Rectangle) {
                System.out.println(s.toString());
                System.out.println("Area = " + s.findArea());

            }
            if (s instanceof Circle) {
                System.out.println(((Circle) s).toString());
                System.out.println("Area = " + s.findArea());

            }
        }

    }

}