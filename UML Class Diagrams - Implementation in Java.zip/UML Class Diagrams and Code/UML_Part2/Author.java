import java.time.LocalDate;

public class Author {
    
    private static int counter=0;
    
    private int authorID=assignID();
    
    private int assignID()
    {
        return ++counter;
    }
    
    private String authorName = "Default Name";
    private LocalDate DOB = LocalDate.of(2000,1,1);


    public Author()
    {
        
    }
    
    public Author(String name)
    {
        this.authorName= name;
    }
    public Author(String name, LocalDate dob)
    {
        this.authorName = name; 
        this.DOB = dob;
    }

    public int getAuthorID() {
        return authorID;
    }



    public String getAuthorName() {
        return authorName;
    }

    public void setAuthorName(String authorName) {
        this.authorName = authorName;
    }

    public LocalDate getDOB() {
        return DOB;
    }

    public void setDOB(int year, int month, int day) {
        this.DOB = LocalDate.of(year, month, day);
    }

    @Override
    public String toString() {
        return "Author{" + "authorID=" + authorID + ", authorName=" + authorName + ", DOB=" + DOB + '}';
    }

    
    public static void main(String[] args) {
        Author a1=new Author();
        Author a2=new Author();
        System.out.println(a1);
        
        a2.setAuthorName("Mohammed");
        a2.setDOB(1983, 07, 29);
        System.out.println(a2);
        
        Author a3=new Author("Ali", LocalDate.of(1983, 07, 29));
        System.out.println(a3);
    }
       
}