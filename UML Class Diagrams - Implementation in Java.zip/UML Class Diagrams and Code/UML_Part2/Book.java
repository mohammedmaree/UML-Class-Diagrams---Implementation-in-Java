import java.time.LocalDate;
import java.util.ArrayList;
public class Book extends Document{
        private int noOfPages;
    private String edition;

    public Book(String title)
    {
        super(title);
    }
    
    public Book(String title, LocalDate doc, ArrayList<Author> authors, String edition, int noOfPages)
    {
        super(title, doc, authors);
        this.edition = edition;
        this.noOfPages = noOfPages;
    }

    public int getNoOfPages() {
        return noOfPages;
    }

    public void setNoOfPages(int noOfPages) {
        this.noOfPages = noOfPages;
    }

    public String getEdition() {
        return edition;
    }

    public void setEdition(String edition) {
        this.edition = edition;
    }

    @Override
    public String toString() {
        return "Book{" + "title=" + super.getTitle() + ", dateOfCreation=" + super.getDateOfCreation() + ", authors=" + super.getAuthors() + " , noOfPages=" + noOfPages + ", edition=" + edition + '}';
    }
       
    public static void main(String[] args) {
        Book b1=new Book("Arabic Book");
        
        System.out.println(b1);
        
    }
 }