import java.time.LocalDate;
import java.util.ArrayList;
public class Document {
    private String title;
    private LocalDate dateOfCreation;
    
    private ArrayList<Author> authors;
    
//    public Document()
//    {
//        
//    }
//    
    public Document(String title, ArrayList<Author> authors)
    {
        this.title = title; 
        this.authors = authors;
    }
    
    public Document(String title)
    {
        this.title = title;
    }

    public Document(String title, LocalDate date)
    {
        this.title = title;
        this.dateOfCreation = date;
    }

    public Document(String title, LocalDate dateOfCreation, ArrayList<Author> authors) {
        this.title = title;
        this.dateOfCreation = dateOfCreation;
        this.authors = authors;
    }
    
    
    @Override
    public String toString() {
        return "Document{" + "title=" + title + ", dateOfCreation=" + dateOfCreation + ", authors=" + authors + '}';
    }

    public LocalDate getDateOfCreation() {
        return dateOfCreation;
    }

    public void setDateOfCreation(LocalDate dateOfCreation) {
        this.dateOfCreation = dateOfCreation;
    }

    public ArrayList<Author> getAuthors() {
        return authors;
    }

    public void setAuthors(ArrayList<Author> authors) {
        this.authors = authors;
    }
    
    public void addAuthor(Author a)
    {
        this.authors.add(a);
    }
    
    public void removeAuthor(Author a)
    {
        this.authors.remove(a);
    }
    
    public void removeAuthorByIndex(int index)
    {
        this.authors.remove(index);
    }
    
    public int getNumberOfAuthors()
    {
        return this.authors.size();
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }
    
    
    
    
    
    public static void main(String[] args) {
        Author a1=new Author("Omar");
        Author a2=new Author("Ali");
        
        ArrayList<Author> authors = new ArrayList<>();
        
        authors.add(a1);
        authors.add(a2);
        
        Document d1=new Document("Arabic Book", authors);
        
        System.out.println("The length of the ArrayList = " + d1.getNumberOfAuthors());
        d1.addAuthor(new Author("Mohammed"));
        
        System.out.println("The length of the ArrayList = " + d1.getNumberOfAuthors());
        
        
        d1.removeAuthorByIndex(2);
        
        System.out.println("The length of the ArrayList = " + d1.getNumberOfAuthors());
        
        System.out.println(d1);
        
    }
    
}