import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Scanner;
public class Document_Manipulation {
    private ArrayList<Document> documents;
    
    private Scanner scan;
        
    public void createNewDocuments()
    {
        
        scan=new Scanner(System.in);
        
        System.out.println("Please enter the number of Documents you want to create:");
        
        int numberOfDocuments, year, month, day, noOfAuthors, noOfPages;
        String title, name, type, edition, subject;
        ArrayList<Author> authors;
        numberOfDocuments = scan.nextInt();
        scan.nextLine();
        
        documents = new ArrayList<>(numberOfDocuments);
        
        for(int i = 0;i<numberOfDocuments ; i++)
        {
            
            System.out.println("Please enter the Type (Document, Book, Email): ");
            type = scan.nextLine();
            
            if(type.equalsIgnoreCase("Document"))
            {
            System.out.println("Please enter the Title of Document " + (i+1));
            title = scan.nextLine();
            
            System.out.println("Please enter the date of creation:\nYear:");
            year = scan.nextInt();
            
            System.out.println("Month:");
            month=scan.nextInt();
            
            System.out.println("Day:");
            day = scan.nextInt();
            
            System.out.println("Please enter the number of authors:");
            noOfAuthors = scan.nextInt();
            
            scan.nextLine();
            
            authors =new ArrayList<>(noOfAuthors);
            
            for(int j =0; j <noOfAuthors;j++)
            {
                System.out.println("Please enter the name of Auhtor " + (j+1));
                name= scan.nextLine();
                authors.add(new Author(name));
            }
            
            documents.add(new Document(title, LocalDate.of(year, month, day), authors));
            }
            
            
            if(type.equalsIgnoreCase("Book"))
            {
            System.out.println("Please enter the Title of Book " + (i+1));
            title = scan.nextLine();
            
            System.out.println("Please enter the date of creation:\nYear:");
            year = scan.nextInt();
            
            System.out.println("Month:");
            month=scan.nextInt();
            
            System.out.println("Day:");
            day = scan.nextInt();
            
            System.out.println("Please enter the number of authors:");
            noOfAuthors = scan.nextInt();
            
            scan.nextLine();
            
            authors =new ArrayList<>(noOfAuthors);
            
            for(int j =0; j <noOfAuthors;j++)
            {
                System.out.println("Please enter the name of Auhtor " + (j+1));
                name= scan.nextLine();
                authors.add(new Author(name));
            }
            
                System.out.println("Please enter the edition:");
                edition = scan.nextLine();
                
                System.out.println("Please enter the number of pages:");
                noOfPages=scan.nextInt();
                scan.nextLine();
            
            documents.add(new Book(title, LocalDate.of(year, month, day), authors, edition, noOfPages));
            }
            
                       if(type.equalsIgnoreCase("Email"))
            {
            System.out.println("Please enter the Title of Email " + (i+1));
            title = scan.nextLine();
            
            System.out.println("Please enter the date of creation:\nYear:");
            year = scan.nextInt();
            
            System.out.println("Month:");
            month=scan.nextInt();
            
            System.out.println("Day:");
            day = scan.nextInt();
            
            System.out.println("Please enter the number of authors:");
            noOfAuthors = scan.nextInt();
            
            scan.nextLine();
            
            authors =new ArrayList<>(noOfAuthors);
            
            for(int j =0; j <noOfAuthors;j++)
            {
                System.out.println("Please enter the name of Auhtor " + (j+1));
                name= scan.nextLine();
                authors.add(new Author(name));
            }
            
                System.out.println("Please enter the subject:");
                subject = scan.nextLine();

            
            documents.add(new Email(title, LocalDate.of(year, month, day), authors, subject));
            }
            
        }
        
    }
    
    public void printDocuments()
    {
        for(int i =0;i<documents.size();i++)
        {
            System.out.println(documents.get(i).toString());
        }
    }
    
    public void printDocumentsV2()
    {
        for(Document d:documents)
        {
            System.out.println(d);
        }
    }
    
    public ArrayList<Book> searchForABook(String title)
    {
        ArrayList<Book> foundBooks = new ArrayList<>();
        
//also works     
        
//        for(int i=0;i<documents.size();i++)
//        {
//            if(documents.get(i) instanceof Book)
//            {
//                if(documents.get(i).getTitle().equalsIgnoreCase(title))
//                {
//                    foundBooks.add((Book)documents.get(i));
//                }
//            }
//        }
        
        for(Document d:documents)
        {
            if(d instanceof Book)
            {
                if(d.getTitle().equalsIgnoreCase(title))
                {
                    foundBooks.add((Book)d);
                }
            }
        }
        
        return foundBooks;
    }
    
    
    public static void main(String[] args) {
        Document_Manipulation dm=new Document_Manipulation();       
        dm.createNewDocuments();
        dm.printDocuments();
        
        ArrayList<Book> books = dm.searchForABook("Test Book");
        
        for(Book b:books)
        {
            System.out.println(b);
        }
    }
    
}