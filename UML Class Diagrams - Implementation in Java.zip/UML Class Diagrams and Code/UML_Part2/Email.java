import java.time.LocalDate;
import java.util.ArrayList;
public class Email extends Document{
 
    
    private String subject;
    private String[] to;

    
    public Email(String title)
    {
        super(title);
      
    }

    public Email(String title, LocalDate dateOfCreation, ArrayList<Author> authors, String subject) {
        super(title, dateOfCreation, authors);
        this.subject = subject;
    }

    @Override
    public String toString() {
        return "Email{" + "title=" + super.getTitle() + ", dateOfCreation=" + super.getDateOfCreation() + ", authors=" + super.getAuthors() + "subject=" + subject + ", to=" + to + '}';
    }
    
    
    
    
 
    public String getSubject() {
        return subject;
    }

    public void setSubject(String subject) {
        this.subject = subject;
    }

    public String[] getTo() {
        return to;
    }

    public void setTo(String[] to) {
        this.to = to;
    }
       
}